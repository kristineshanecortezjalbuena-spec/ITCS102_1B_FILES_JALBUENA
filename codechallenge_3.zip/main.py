sender_name = input("Enter sender name: ")
item_type = input("Enter type of item: ")
is_fragile = input("Is the item fragile? True/False: ")== "True"
weight = float(input("Enter weigth in kg: "))
is_express = input("Is it is express? True/False: ")== "True"
is_international = input("Is international? True/False: ")== "True"
distance = float(input("Enter distance in km: "))

base_cost = (weight*2.50) + (distance*0.15)

if weight <= 2 and distance <= 100 and not is_express and not is_international:
    total = 0.00
elif is_express and is_international:
    total = (base_cost*1.40) + 50
elif is_express or (is_international and weight > 20):
    total = (base_cost*1.20) + 25
elif weight > 30 or distance > 1000:
    total = base_cost + 30
else:
    total = base_cost
    
print("\n---- Global Freight Calculator ---")
print("Sender:",sender_name)
print("Item Type", item_type)
print("Fragile", is_fragile)
print("Total Shipping Cost: ₱{:.2f}".format(total))